/*
 * DarAcceso.java
 *
 * Creado 23 de abril de 2007, 12:49
 *
 * Telefonica I+D Copyright 2006-2007
 */

package icaro.aplicaciones.informacion.dominioObjetivos;

import icaro.infraestructura.patronAgenteCognitivo.procesadorconocimiento.entidadesbasicas.Objective;

/**
 *
 * @author Carlos Rodr&iacute;guez Fern&aacute;ndez
 */
public class DarAcceso extends Objective{
    
    /** Crea una nueva instancia de DarAcceso */
    public DarAcceso() {
        super.setID("DarAcceso");
    }
    
}
