/*
 * TerminarServicioAcceso.java
 *
 * Created on 22 de mayo de 2007, 11:39
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package icaro.aplicaciones.informacion.dominioObjetivos;

import icaro.infraestructura.patronAgenteCognitivo.procesadorconocimiento.entidadesbasicas.Objective;



/**
 *
 * @author Javi
 */
public class TerminarServicioAcceso extends Objective{
    
    /** Creates a new instance of TerminarServicioAcceso */
    public TerminarServicioAcceso() {
    	super();
    	//this.setSolving();
    }
    
}
