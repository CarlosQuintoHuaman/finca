package icaro.aplicaciones.recursos.recTestPersonalidad;

/**
 * Excepciones generadas por la clase MensajesSistema
 */
public class ExcepcionPreguntas extends Exception {

  public ExcepcionPreguntas(String s) {
      super(s);
  }
}