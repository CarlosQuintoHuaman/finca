package icaro.aplicaciones.recursos.recInformacionUsuario;

/**
 * Excepciones generadas por la clase MensajesSistema
 */
public class ExcepcionMensajes extends Exception {

  public ExcepcionMensajes(String s) {
      super(s);
  }
}