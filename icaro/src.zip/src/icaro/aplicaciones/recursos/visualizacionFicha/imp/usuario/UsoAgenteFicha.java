package icaro.aplicaciones.recursos.visualizacionFicha.imp.usuario;

/*
import icaro.aplicaciones.informacion.dominioClases.aplicacionFicha.DatosFichaSinValidar;
*/
import icaro.aplicaciones.informacion.dominioClases.aplicacionFicha.DatosFichaSinValidar;
import icaro.aplicaciones.recursos.visualizacionFicha.imp.*;
import icaro.herramientas.descripcionorganizacion.asistentecreacion.evento.Evento;
import icaro.infraestructura.entidadesBasicas.EventoInput;
import icaro.infraestructura.entidadesBasicas.NombresPredefinidos;
import icaro.infraestructura.patronAgenteCognitivo.ItfUsoAgenteCognitivo;
import icaro.infraestructura.patronAgenteReactivo.factoriaEInterfaces.ItfUsoAgenteReactivo;
import icaro.infraestructura.recursosOrganizacion.repositorioInterfaces.ItfUsoRepositorioInterfaces;
import icaro.infraestructura.recursosOrganizacion.repositorioInterfaces.RepositorioInterfaces;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 
 *@author     Felipe Polo
 *@created    30 de noviembre de 2007
 */
public class UsoAgenteFicha {

    protected ItfUsoRepositorioInterfaces itfUsoRepositorioInterfaces;
    protected ClaseGeneradoraVisualizacionFicha visualizador;
    private String nombreAgenteFicha;
    private String tipoAgenteFicha;
    private ItfUsoAgenteReactivo usoAgenteControlador;

    public UsoAgenteFicha(ClaseGeneradoraVisualizacionFicha vis) {

        visualizador = vis;
        
    }

    private void getInformacionAgente() {
        nombreAgenteFicha = visualizador.getNombreAgenteControlador();
        tipoAgenteFicha = visualizador.getTipoAgenteControlador();

        if (nombreAgenteFicha.equals(NombresPredefinidos.NOMBRE_AGENTE_APLICACION + "FichaEsclavo")) {
            nombreAgenteFicha = NombresPredefinidos.NOMBRE_AGENTE_APLICACION + "FichaMaestro";
        }
    }

    public ClaseGeneradoraVisualizacionFicha getVisualizador() {
        return visualizador;

    }

    public void notificacionCierreSistema() {
         try {
             nombreAgenteFicha = visualizador.getNombreAgenteControlador();
            usoAgenteControlador = (ItfUsoAgenteReactivo) RepositorioInterfaces.instance().obtenerInterfaz(nombreAgenteFicha);
        } catch (Exception ex) {
            Logger.getLogger(UsoAgenteFicha.class.getName()).log(Level.SEVERE, null, ex);
        }       
        //cierre de ventanas que genera cierre del sistema

        try {
            getInformacionAgente();
            //me aseguro de crear las interfaces si han sido registradas ya
            if (itfUsoRepositorioInterfaces == null) {
                itfUsoRepositorioInterfaces = RepositorioInterfaces.instance();
            }
            if (tipoAgenteFicha.equals(NombresPredefinidos.TIPO_REACTIVO)) {
                ItfUsoAgenteReactivo itfUsoAgente = (ItfUsoAgenteReactivo) itfUsoRepositorioInterfaces.obtenerInterfaz(NombresPredefinidos.ITF_USO + nombreAgenteFicha);
                if (itfUsoAgente != null) {
                    itfUsoAgente.aceptaEvento(new EventoInput("peticion_terminacion_usuario", "VisualizacionFicha", nombreAgenteFicha));
                }
            }
        } catch (Exception e) {
            System.out.println("Ha habido un error al enviar el evento termina al agente");
            e.printStackTrace();
        }
        //usoAgenteControlador.aceptaEvento(new Evento("peticion_terminacion_usuario"));
    }

   public void valida(String username, String password) {
      
	   try {
            //nombreAgenteFicha = visualizador.getNombreAgenteFicha();
		   nombreAgenteFicha = visualizador.getNombreAgenteControlador();
            System.out.println("Nombre de agente en visualizador:"+nombreAgenteFicha);
            usoAgenteControlador = (ItfUsoAgenteReactivo) RepositorioInterfaces.instance().obtenerInterfaz(NombresPredefinidos.ITF_USO + nombreAgenteFicha);
        } catch (Exception ex) {
            Logger.getLogger(UsoAgenteFicha.class.getName()).log(Level.SEVERE, null, ex);
        }       
         
    	getInformacionAgente();
        //provoca la petici�n de autentificaci�n
    	
        String[] datosEnvio = new String[]{username, password,"A"};
        /*try {
			usoAgenteControlador.aceptaEvento(new EventoInput("autenticacion",datosEnvio,"VisualizacionFicha1", nombreAgenteFicha));
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
      
        try {
            if (itfUsoRepositorioInterfaces == null) {
                itfUsoRepositorioInterfaces = RepositorioInterfaces.instance();
            }

            if (tipoAgenteFicha.equals(NombresPredefinidos.TIPO_REACTIVO)) {
                //AgenteAplicacionFicha
                ItfUsoAgenteReactivo itfUsoAgente = (ItfUsoAgenteReactivo) itfUsoRepositorioInterfaces.obtenerInterfaz(NombresPredefinidos.ITF_USO + nombreAgenteFicha);
                if (itfUsoAgente != null) {
                    itfUsoAgente.aceptaEvento(new EventoInput("infoFicha", datosEnvio, "VisualizacionFicha1", nombreAgenteFicha));
                }
            } else if (tipoAgenteFicha.equals(NombresPredefinidos.TIPO_COGNITIVO)) {

                
                ItfUsoAgenteCognitivo cognitivo = (ItfUsoAgenteCognitivo) itfUsoRepositorioInterfaces.obtenerInterfaz(NombresPredefinidos.ITF_USO + nombreAgenteFicha);
                DatosFichaSinValidar sinValidar = new DatosFichaSinValidar(username, password,"a");
                EventoInput evento = new EventoInput("", sinValidar, "Recurso:VisualizacionFicha", nombreAgenteFicha);
                if (cognitivo != null) {
                    cognitivo.aceptaEvento(evento);
                }
            }

        } catch (Exception e) {
            System.out.println("Ha habido un error al enviar el usuario y el password al agente de Ficha ");
            e.printStackTrace();
        }
        
    }
}

