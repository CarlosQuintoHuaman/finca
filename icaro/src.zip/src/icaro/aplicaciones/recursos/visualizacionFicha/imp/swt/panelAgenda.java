package icaro.aplicaciones.recursos.visualizacionFicha.imp.swt;

import icaro.aplicaciones.recursos.visualizacionFicha.imp.ClaseGeneradoraVisualizacionFicha;
import icaro.aplicaciones.recursos.visualizacionFicha.imp.usuario.UsoAgenteFicha;

import java.lang.reflect.Array;
import java.util.ArrayList;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Composite;

/*
import persistencia.Persistencia;

import control.Controlador;
*/
public class panelAgenda {

	private Shell sShell = null;  //  @jve:decl-index=0:visual-constraint="-17,-9"
	private Button bFicha = null;
	private Composite composite = null;
	private Table table = null;
	private ArrayList horas = new ArrayList();  //  @jve:decl-index=0:
	private ClaseGeneradoraVisualizacionFicha p;
	/*
        private visualizador c;
	*/
         private static final long serialVersionUID = 1L;
		
	private UsoAgenteFicha usoAgente; //comunicaci�n con el agente (control)
			
	public panelAgenda(ClaseGeneradoraVisualizacionFicha visualizador){
		usoAgente = new UsoAgenteFicha(visualizador);
	/*			initComponents();
				this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
         */
         }
         public void mostrar(){ 	
	/*
	 * This method initializes sShell
	 */
             createSShell();
         }  
         public void ocultar(){ 	
	/*
	 * This method debe ocultar la ventana
	 */
              } 
        public void destruir(){ 	
	/*
	 * This method 
	 */ 
         }
        
    public UsoAgenteFicha getAgente() {
    	return usoAgente;
    }
    
	private void createSShell() {
		Display display = new Display();
		Display.setAppName("Doctoris");
		sShell = new Shell();
		sShell.setText("Shell");
		sShell.setLayout(null);
		sShell.setSize(new Point(600, 400));
		bFicha = new Button(sShell, SWT.NONE);
		bFicha.setBounds(new Rectangle(259, 303, 118, 43));
		bFicha.setText("Crear Ficha");
		/*
                createComposite();
		*/
		GridLayout layout = new GridLayout(1,false);
	
        SelectionAdapter sabFicha = new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e){
				 
                                 //Ficha f = new Ficha(sShell,p,c);
                                 
				//while (!f.isDisposed()) {
					if (!sShell.getDisplay().readAndDispatch()) {
						sShell.getDisplay().sleep();
					}
				//}
				abrirFicha();
			}
		};
		bFicha.addSelectionListener(sabFicha);

		
		sShell.setText("Comienzo");
		sShell.setLayout(layout);
        sShell.pack();
        sShell.open();
        while (!sShell.isDisposed()){
            if(!display.readAndDispatch())
            display.sleep();
        }
       
	}
	
	public void abrirFicha() {
		panelFicha f = new panelFicha(sShell,this);
	}
}

	 /* This method initializes composite*/
	/*private void createComposite() {
		horas.add("9");
		horas.add("10");
		
		composite = new Composite(sShell, SWT.NONE);
		composite.setLayout(null);
		composite.setBounds(new Rectangle(89, 33, 421, 218));
		table = new Table(composite, SWT.BORDER | SWT.FULL_SELECTION | SWT.MULTI);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		table.setItemCount(0);
		table.setBounds(new Rectangle(18, 16, 385, 182));
		
		table.addMouseListener(new org.eclipse.swt.events.MouseAdapter() {
			public void mouseDoubleClick(org.eclipse.swt.events.MouseEvent e) {
				System.out.println("mouseDoubleClick()"); // TODO Auto-generated Event stub mouseDoubleClick()				
				//System.out.println("Fila:"+i[0]);
				
                                Cita c = new Cita();
			}
        
		});
		TableColumn tableColumn = new TableColumn(table, SWT.CENTER);
		tableColumn.setWidth(60);
		tableColumn.setData(horas);
		tableColumn.setText("Horas");
		TableColumn tableColumn2 = new TableColumn(table, SWT.CENTER);
		tableColumn2.setWidth(60);
		tableColumn2.setText("Lunes");
		TableColumn tableColumn1 = new TableColumn(table, SWT.CENTER);
		tableColumn1.setWidth(60);
		tableColumn1.setText("Martes");
		TableColumn tableColumn5 = new TableColumn(table, SWT.CENTER);
		tableColumn5.setWidth(70);
		tableColumn5.setText("Miercoles");
		TableColumn tableColumn4 = new TableColumn(table, SWT.CENTER);
		tableColumn4.setWidth(60);
		tableColumn4.setText("Jueves");
		TableColumn tableColumn3 = new TableColumn(table, SWT.CENTER);
		tableColumn3.setWidth(60);
		tableColumn3.setText("Viernes");
		
		
		TableItem item1 = new TableItem(table,0);
		item1.setText(new String[]{"8","b","c","d","e","f"});
		TableItem item2 = new TableItem(table,0);
		item2.setText(new String[]{"9","b","c","d","e","f"});
		
}	}*/

