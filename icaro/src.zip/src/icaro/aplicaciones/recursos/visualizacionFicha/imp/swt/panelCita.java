package icaro.aplicaciones.recursos.visualizacionFicha.imp.swt;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Text;

public class panelCita {

	private Shell sShell = null;
	private Label label = null;
	private Label label1 = null;
	private Text text = null;
	private Text text1 = null;
	
	public panelCita(){
		createSShell();
	}
	/**
	 * This method initializes sShell
	 */
	private void createSShell() {
		sShell = new Shell();
		sShell.setText("Cita");
		sShell.setSize(new Point(300, 200));
		sShell.setLayout(null);
		label = new Label(sShell, SWT.NONE);
		label.setBounds(new Rectangle(19, 17, 50, 20));
		label.setText("Hora");
		label1 = new Label(sShell, SWT.NONE);
		label1.setBounds(new Rectangle(16, 55, 55, 39));
		label1.setText("Nombre");
		text = new Text(sShell, SWT.BORDER);
		text.setBounds(new Rectangle(98, 13, 88, 27));
		text1 = new Text(sShell, SWT.BORDER);
		text1.setBounds(new Rectangle(99, 52, 86, 27));
		
		
		sShell.setText("Dar Cita");
		//sShell.setLayout(layout);
        sShell.pack();
        sShell.open();
        /*while (!sShell.isDisposed()){
            if(!display.readAndDispatch())
            display.sleep();
        }*/
	}

}
