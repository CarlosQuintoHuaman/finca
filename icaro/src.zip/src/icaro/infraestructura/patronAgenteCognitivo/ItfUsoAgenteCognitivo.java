/*
 * ItfPercepcionAgente.java
 *
 * Creado 18 de abril de 2007, 13:30
 *
 * Telefonica I+D Copyright 2006-2007
 */

package icaro.infraestructura.patronAgenteCognitivo;

import icaro.infraestructura.entidadesBasicas.interfaces.ItfEventos;
import icaro.infraestructura.entidadesBasicas.interfaces.ItfMensajeSimple;

/**
 * 
 * @author Carlos Rodr&iacute;guez Fern&aacute;ndez
 */
public interface ItfUsoAgenteCognitivo extends ItfEventos,
		ItfMensajeSimple {

}
