package icaro.infraestructura.patronAgenteCognitivo.percepcion;

public interface ItfGestionPercepcionAgenteCognitivo {

	public void termina();
	
	public void arranca();
}
