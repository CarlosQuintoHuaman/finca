package icaro.infraestructura.patronAgenteCognitivo.percepcion;

import icaro.infraestructura.patronAgenteCognitivo.ItfUsoAgenteCognitivo;



public abstract class PercepcionAgenteCognitivo implements ItfUsoAgenteCognitivo, ItfGestionPercepcionAgenteCognitivo {

}
