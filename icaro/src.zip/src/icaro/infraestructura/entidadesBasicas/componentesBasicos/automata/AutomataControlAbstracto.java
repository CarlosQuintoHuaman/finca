package icaro.infraestructura.entidadesBasicas.componentesBasicos.automata;



/**
 *
 *@author     Felipe Polo
 *@created    3 de Diciembre de 2007
 */

public abstract class AutomataControlAbstracto implements ItfUsoAutomata {

}
