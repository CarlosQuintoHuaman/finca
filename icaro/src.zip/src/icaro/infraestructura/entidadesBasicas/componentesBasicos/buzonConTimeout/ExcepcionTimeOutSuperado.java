package icaro.infraestructura.entidadesBasicas.componentesBasicos.buzonConTimeout;
/**
 *  Clase de las excepciones de tiempo superado al consumir del buz�n
 *
 *@author     Jorge Gonz�lez
 *@created    2 de octubre de 2001
 */
public class ExcepcionTimeOutSuperado extends java.lang.Exception {

	private static final long serialVersionUID = 1L;
}
