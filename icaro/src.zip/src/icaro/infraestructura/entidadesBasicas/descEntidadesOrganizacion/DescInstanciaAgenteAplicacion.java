package icaro.infraestructura.entidadesBasicas.descEntidadesOrganizacion;


public class DescInstanciaAgenteAplicacion extends DescInstanciaAgente {
	
}
