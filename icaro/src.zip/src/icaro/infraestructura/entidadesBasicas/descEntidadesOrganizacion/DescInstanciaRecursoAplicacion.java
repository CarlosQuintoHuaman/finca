package icaro.infraestructura.entidadesBasicas.descEntidadesOrganizacion;

import icaro.infraestructura.entidadesBasicas.descEntidadesOrganizacion.jaxb.DescRecursoAplicacion;

public class DescInstanciaRecursoAplicacion extends DescInstancia {
	
	private DescRecursoAplicacion descRecurso;
	
	public DescRecursoAplicacion getDescRecurso() {
		return descRecurso;
	}
	public void setDescRecurso(DescRecursoAplicacion descRecurso) {
		this.descRecurso = descRecurso;
	}
	
	
}
