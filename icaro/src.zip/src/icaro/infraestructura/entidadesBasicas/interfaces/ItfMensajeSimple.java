package icaro.infraestructura.entidadesBasicas.interfaces;

import icaro.infraestructura.entidadesBasicas.MensajeAgente;

public interface ItfMensajeSimple {
	
	 public void aceptaMensaje(MensajeAgente mensaje);

}
