package icaro.infraestructura.patronRecursoSimple;

/**
 * 
 *@author     Felipe Polo
 *@created    30 de noviembre de 2007
 */

public interface ItfUsoRecursoSimple{

}
