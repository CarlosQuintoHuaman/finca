package icaro.infraestructura.patronRecursoSimple;


import icaro.infraestructura.entidadesBasicas.interfaces.InterfazGestion;

/**
 * 
 *@author     Felipe Polo
 *@created    30 de noviembre de 2007
 */

public interface ItfGestionRecursoSimple extends InterfazGestion {

	/*public String obtenerEstado()
		throws Exception;*/
}
