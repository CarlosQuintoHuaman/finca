package icaro.infraestructura.patronRecursoSimple;

public class UsoRecursoException extends Exception {

	public UsoRecursoException(String mensaje) {
		//TODO enviar mensaje al recurso de trazas
	}
	

}
