/*
 *  Copyright 2001 Telef�nica I+D
 *
 *
 *  All rights reserved
 */
package icaro.infraestructura.patronAgenteReactivo.percepcion.factoriaEInterfaces ;

/**
 *@author     Jorge M. Gonz�lez Martin
 *@created    3 de septiembre de 2001
 *@version    1.0
 */

public class NoSeAceptoEventoExcepcion extends java.lang.Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 *  Constructor for the NoSeAceptoEventoExcapcion object
	 */
	public NoSeAceptoEventoExcepcion()
	{
	}
}
