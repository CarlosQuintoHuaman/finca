package icaro.infraestructura.patronAgenteReactivo.percepcion.factoriaEInterfaces;


/**
 * 
 *@author     Felipe Polo
 *@created    30 de noviembre de 2007
 */

public abstract class PercepcionAbstracto implements ItfConsumidorPercepcion,ItfProductorPercepcion {

}
